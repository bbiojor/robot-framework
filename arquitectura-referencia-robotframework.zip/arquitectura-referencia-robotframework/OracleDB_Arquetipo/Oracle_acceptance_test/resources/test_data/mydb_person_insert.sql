INSERT INTO person VALUES(101,"john","travolta");
INSERT INTO person VALUES(102,"pepito","perez");
INSERT INTO person VALUES(103,"juan","valdez");
INSERT INTO person VALUES(104,"james","rodriguez");
INSERT INTO person VALUES(105,"nairo","quintana");
INSERT INTO person VALUES(106,"michael","jackson");
